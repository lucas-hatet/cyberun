"use client"
import React from "react"
import "./styles.css"

// Sample data - données initiales qui doivent être visibles
const initialData = {
  user: {
    a08: "John Doe",
    a09: "React development\nTypeScript\nJSON Schema",
  },
  item: {
    s01: ["vendor", "integrator"],
    p02: "no",
    i01: [
      { country: "France", percent: 30 },
      { country: "United States of America", percent: 50 },
      { country: "Germany", percent: 20 },
    ],
  },
}

// Formulaire personnalisé qui affiche directement les données
const CustomReadOnlyForm = () => {
  return (
    <div className="custom-form">
      <div className="jsonforms-group">
        <div className="jsonforms-group-header">
          <h3 className="jsonforms-group-label">My User</h3>
        </div>
        <div className="jsonforms-group-content">
          <div className="jsonforms-control read-only-control">
            <div className="two-column-layout">
              <div className="question-column">
                <label className="control-label">Name</label>
              </div>
              <div className="answer-column">
                <div className="read-only-value">{initialData.user.a08}</div>
              </div>
            </div>
          </div>

          <div className="jsonforms-control read-only-multiline">
            <div className="full-width-layout">
              <label className="control-label">description of your skills</label>
              <div className="read-only-multiline-value">
                {initialData.user.a09.split("\n").map((line, i) => (
                  <React.Fragment key={i}>
                    {line}
                    <br />
                  </React.Fragment>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="jsonforms-group">
        <div className="jsonforms-group-header">
          <h3 className="jsonforms-group-label">Profile</h3>
        </div>
        <div className="jsonforms-group-content">
          <div className="jsonforms-control read-only-enum">
            <div className="two-column-layout">
              <div className="question-column">
                <label className="control-label">Who provides the contract?</label>
              </div>
              <div className="answer-column">
                {initialData.item.s01.map((val) => (
                  <span key={val} className="enum-badge">
                    {val}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="jsonforms-control read-only-enum">
            <div className="two-column-layout">
              <div className="question-column">
                <label className="control-label">Are you currently student?</label>
                <p className="control-description">
                  if you're currently student and also working for a company, check no
                </p>
              </div>
              <div className="answer-column">
                <span className="enum-badge">{initialData.item.p02}</span>
              </div>
            </div>
          </div>

          <div className="jsonforms-control read-only-countries">
            <div className="full-width-layout">
              <label className="control-label">In which countries did you worked / How long (in percent)?</label>
              <p className="control-description">
                please be sure to include only countries where you effectively worked more than 7 days
              </p>

              <div className="countries-table-container">
                <table className="countries-table">
                  <thead>
                    <tr>
                      <th>Country</th>
                      <th>Percentage</th>
                    </tr>
                  </thead>
                  <tbody>
                    {initialData.item.i01.map((item, index) => (
                      <tr key={index}>
                        <td>{item.country}</td>
                        <td>{item.percent}%</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr>
                      <td>
                        <strong>Total</strong>
                      </td>
                      <td>
                        <strong>{initialData.item.i01.reduce((sum, item) => sum + item.percent, 0)}%</strong>
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

const App = () => {
  return (
    <div className="app-container">
      <h1>JSON Forms Read-Only View</h1>
      <div className="form-container">
        <CustomReadOnlyForm />
      </div>
    </div>
  )
}

export default App
