import React from "react"
import {
  type ControlProps,
  rankWith,
  scopeEndsWith,
  and,
  type Tester,
  type JsonFormsRendererRegistryEntry,
  type GroupLayout,
  uiTypeIs,
  type LayoutProps,
  type VerticalLayout,
} from "@jsonforms/core"
import { withJsonFormsControlProps, withJsonFormsLayoutProps, JsonFormsDispatch } from "@jsonforms/react"

// Fonction simplifiée pour extraire la clé de propriété à partir du scope
const getPropertyKey = (scope: string): { parent: string; key: string } => {
  // Exemples de scopes:
  // #/properties/user/properties/a08 -> { parent: "user", key: "a08" }
  // #/properties/item/properties/s01 -> { parent: "item", key: "s01" }

  const parts = scope.split("/")
  const key = parts[parts.length - 1]
  const parentIndex = parts.indexOf("properties") + 1
  const parent = parentIndex < parts.length ? parts[parentIndex] : ""

  return { parent, key }
}

// Fonction pour obtenir la valeur directement à partir de la structure de données
const getValueDirectly = (data: any, scope: string): any => {
  if (!data || !scope) return undefined

  const { parent, key } = getPropertyKey(scope)

  if (parent && key && data[parent]) {
    return data[parent][key]
  }

  return undefined
}

// Read-only text renderer
export const ReadOnlyTextRenderer = ({ data, schema, uischema }: ControlProps) => {
  const label = schema.title || ""
  const description = schema.description
  const scope = uischema.scope || ""

  // Obtenir la valeur directement
  const value = getValueDirectly(data, scope)

  return (
    <div className="jsonforms-control read-only-control">
      <div className="two-column-layout">
        <div className="question-column">
          <label className="control-label">{label}</label>
          {description && <p className="control-description">{description}</p>}
        </div>
        <div className="answer-column">
          <div className="read-only-value">{value !== undefined ? String(value) : "-"}</div>
        </div>
      </div>
    </div>
  )
}

// Read-only multiline text renderer
export const ReadOnlyMultilineRenderer = ({ data, schema, uischema }: ControlProps) => {
  const label = schema.title || ""
  const description = schema.description
  const scope = uischema.scope || ""

  // Obtenir la valeur directement
  const value = getValueDirectly(data, scope)

  // Pour le débogage
  console.log("Multiline scope:", scope)
  console.log("Multiline value:", value)
  console.log("Data:", data)

  return (
    <div className="jsonforms-control read-only-multiline">
      <div className="full-width-layout">
        <label className="control-label">{label}</label>
        {description && <p className="control-description">{description}</p>}
        <div className="read-only-multiline-value">
          {value
            ? String(value)
                .split("\n")
                .map((line: string, i: number) => (
                  <React.Fragment key={i}>
                    {line}
                    <br />
                  </React.Fragment>
                ))
            : "-"}
        </div>
      </div>
    </div>
  )
}

// Read-only enum renderer
export const ReadOnlyEnumRenderer = ({ data, schema, uischema }: ControlProps) => {
  const label = schema.title || ""
  const description = schema.description
  const scope = uischema.scope || ""

  // Obtenir la valeur directement
  const value = getValueDirectly(data, scope)

  const renderEnumValue = (val: string) => (
    <span key={val} className="enum-badge">
      {val}
    </span>
  )

  return (
    <div className="jsonforms-control read-only-enum">
      <div className="two-column-layout">
        <div className="question-column">
          <label className="control-label">{label}</label>
          {description && <p className="control-description">{description}</p>}
        </div>
        <div className="answer-column">
          {Array.isArray(value)
            ? value.map((v) => renderEnumValue(String(v)))
            : value
              ? renderEnumValue(String(value))
              : "-"}
        </div>
      </div>
    </div>
  )
}

// Read-only array renderer for countries with percentages
export const ReadOnlyArrayRenderer = ({ data, schema, uischema }: ControlProps) => {
  const label = schema.title || ""
  const description = schema.description
  const scope = uischema.scope || ""

  // Obtenir la valeur directement
  const value = getValueDirectly(data, scope)

  // Calculate total percentage
  const totalPercentage = Array.isArray(value) ? value.reduce((sum, item) => sum + (item.percent || 0), 0) : 0

  return (
    <div className="jsonforms-control read-only-countries">
      <div className="full-width-layout">
        <label className="control-label">{label}</label>
        {description && <p className="control-description">{description}</p>}

        <div className="countries-table-container">
          <table className="countries-table">
            <thead>
              <tr>
                <th>Country</th>
                <th>Percentage</th>
              </tr>
            </thead>
            <tbody>
              {Array.isArray(value) && value.length > 0 ? (
                value.map((item, index) => (
                  <tr key={index}>
                    <td>{item.country}</td>
                    <td>{item.percent}%</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={2}>No data available</td>
                </tr>
              )}
            </tbody>
            <tfoot>
              <tr>
                <td>
                  <strong>Total</strong>
                </td>
                <td>
                  <strong>{totalPercentage}%</strong>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  )
}

// Solution alternative pour le cas où la méthode ci-dessus ne fonctionne pas
export const ReadOnlyMultilineRendererAlternative = ({ data }: ControlProps) => {
  // Accès direct à la valeur spécifique
  const value = data?.user?.a09

  return (
    <div className="jsonforms-control read-only-multiline">
      <div className="full-width-layout">
        <label className="control-label">description of your skills</label>
        <div className="read-only-multiline-value">
          {value
            ? String(value)
                .split("\n")
                .map((line: string, i: number) => (
                  <React.Fragment key={i}>
                    {line}
                    <br />
                  </React.Fragment>
                ))
            : "-"}
        </div>
      </div>
    </div>
  )
}

// Group renderer
export const ReadOnlyGroupRenderer = ({
  uischema,
  schema,
  path,
  renderers,
  cells,
  enabled,
  visible,
  data,
}: LayoutProps) => {
  const groupLayout = uischema as GroupLayout

  if (!visible) {
    return null
  }

  return (
    <div className="jsonforms-group">
      {groupLayout.label && (
        <div className="jsonforms-group-header">
          <h3 className="jsonforms-group-label">{groupLayout.label}</h3>
        </div>
      )}
      <div className="jsonforms-group-content">
        {groupLayout.elements.map((element, index) => (
          <JsonFormsDispatch
            key={index}
            uischema={element}
            schema={schema}
            path={path}
            renderers={renderers}
            cells={cells}
            enabled={enabled}
            data={data}
          />
        ))}
      </div>
    </div>
  )
}

// Vertical layout renderer
export const ReadOnlyLayoutRenderer = ({
  uischema,
  schema,
  path,
  renderers,
  cells,
  enabled,
  visible,
  data,
}: LayoutProps) => {
  const layout = uischema as VerticalLayout

  if (!visible) {
    return null
  }

  return (
    <div className="jsonforms-layout vertical-layout">
      {layout.elements.map((element, index) => (
        <JsonFormsDispatch
          key={index}
          uischema={element}
          schema={schema}
          path={path}
          renderers={renderers}
          cells={cells}
          enabled={enabled}
          data={data}
        />
      ))}
    </div>
  )
}

// Testers for each renderer
const isCountriesArrayControl: Tester = and(uiTypeIs("Control"), scopeEndsWith("i01"))
const isMultiEnumArrayControl: Tester = and(uiTypeIs("Control"), scopeEndsWith("s01"))
const isEnumSingleControl: Tester = and(uiTypeIs("Control"), scopeEndsWith("p02"))
const isMultilineTextControl: Tester = and(uiTypeIs("Control"), scopeEndsWith("a09"))
const isSimpleTextControl: Tester = and(uiTypeIs("Control"), scopeEndsWith("a08"))

// Create the renderer registry entries
export const readOnlyRenderers: JsonFormsRendererRegistryEntry[] = [
  // Specific control renderers with high rank
  {
    tester: rankWith(10, isCountriesArrayControl),
    renderer: withJsonFormsControlProps(ReadOnlyArrayRenderer),
  },
  {
    tester: rankWith(9, isMultiEnumArrayControl),
    renderer: withJsonFormsControlProps(ReadOnlyEnumRenderer),
  },
  {
    tester: rankWith(8, isEnumSingleControl),
    renderer: withJsonFormsControlProps(ReadOnlyEnumRenderer),
  },
  {
    tester: rankWith(7, isMultilineTextControl),
    renderer: withJsonFormsControlProps(ReadOnlyMultilineRenderer),
  },
  {
    tester: rankWith(6, isSimpleTextControl),
    renderer: withJsonFormsControlProps(ReadOnlyTextRenderer),
  },

  // Layout renderers
  {
    tester: rankWith(5, uiTypeIs("Group")),
    renderer: withJsonFormsLayoutProps(ReadOnlyGroupRenderer),
  },
  {
    tester: rankWith(4, uiTypeIs("VerticalLayout")),
    renderer: withJsonFormsLayoutProps(ReadOnlyLayoutRenderer),
  },
]
