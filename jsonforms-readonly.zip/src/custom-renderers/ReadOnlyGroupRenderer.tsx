import { type GroupLayout, type RankedTester, rankWith, uiTypeIs, type LayoutProps } from "@jsonforms/core"
import { withJsonFormsLayoutProps } from "@jsonforms/react"
import { JsonFormsDispatch } from "@jsonforms/react"

/**
 * A custom renderer for group layouts
 */
export const ReadOnlyGroupRenderer = ({ uischema, schema, path, visible }: LayoutProps) => {
  const groupLayout = uischema as GroupLayout

  if (!visible) {
    return null
  }

  return (
    <div className="read-only-group-container">
      {groupLayout.label && (
        <div className="read-only-group-header">
          <h3 className="read-only-group-title">{groupLayout.label}</h3>
        </div>
      )}
      <div className="read-only-group-content">
        {groupLayout.elements.map((element, index) => (
          <JsonFormsDispatch key={index} uischema={element} schema={schema} path={path} />
        ))}
      </div>
    </div>
  )
}

export const readOnlyGroupTester: RankedTester = rankWith(3, uiTypeIs("Group"))

export default withJsonFormsLayoutProps(ReadOnlyGroupRenderer)
