import {
  type ControlProps,
  isEnumControl,
  type RankedTester,
  rankWith,
  isStringControl,
  and,
  hasType,
  optionIs,
} from "@jsonforms/core"
import { withJsonFormsControlProps } from "@jsonforms/react"

/**
 * A custom renderer for single-line text fields and enums
 * Displays question on left, answer on right
 */
export const ReadOnlyLabelRenderer = ({ data, path, schema, uischema }: ControlProps) => {
  const value = data ? data[path.split("/").pop() as string] : undefined
  const isEnum = isEnumControl(uischema, schema)
  const isMultiEnum = Array.isArray(value)

  return (
    <div className="read-only-label-container">
      <div className="read-only-label-left">
        <div className="read-only-label-title">{schema.title || path}</div>
        {schema.description && <div className="read-only-label-description">{schema.description}</div>}
      </div>
      <div className="read-only-label-right">
        {isEnum ? (
          isMultiEnum ? (
            <div className="read-only-enum-container">
              {value &&
                value.map((item: string, index: number) => (
                  <span key={index} className="read-only-enum-badge">
                    {item}
                  </span>
                ))}
            </div>
          ) : (
            <span className="read-only-enum-badge">{value}</span>
          )
        ) : (
          <span className="read-only-text">{value || ""}</span>
        )}
      </div>
    </div>
  )
}

export const readOnlyLabelTester: RankedTester = rankWith(
  3,
  and(
    isStringControl,
    hasType("string"),
    (uischema, schema) => !schema.hasOwnProperty("format") && !optionIs("multi", true)(uischema),
  ),
)

export default withJsonFormsControlProps(ReadOnlyLabelRenderer)
