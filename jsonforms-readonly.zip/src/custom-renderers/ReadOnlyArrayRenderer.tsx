import { type ControlProps, type RankedTester, rankWith, isArrayControl, and, hasType } from "@jsonforms/core"
import { withJsonFormsControlProps } from "@jsonforms/react"

/**
 * A custom renderer for array fields
 * Specialized for the country/percentage table
 */
export const ReadOnlyArrayRenderer = ({ data, path, schema, uischema }: ControlProps) => {
  const propName = path.split("/").pop() as string
  const value = data ? data[propName] : undefined
  const isCountryPercentTable = propName === "i01"

  if (!value || !Array.isArray(value)) {
    return (
      <div className="read-only-array-container">
        <div className="read-only-array-title">{schema.title || path}</div>
        {schema.description && <div className="read-only-array-description">{schema.description}</div>}
        <div className="read-only-array-empty">No data available</div>
      </div>
    )
  }

  if (isCountryPercentTable) {
    return (
      <div className="read-only-array-container">
        <div className="read-only-array-title">{schema.title || path}</div>
        {schema.description && <div className="read-only-array-description">{schema.description}</div>}
        <div className="read-only-country-table">
          <div className="read-only-country-header">
            <div className="read-only-country-cell">Country</div>
            <div className="read-only-country-cell">Percentage</div>
          </div>
          {value.map((item: any, index: number) => (
            <div key={index} className="read-only-country-row">
              <div className="read-only-country-cell">{item.country}</div>
              <div className="read-only-country-cell">{item.percent}%</div>
            </div>
          ))}
          <div className="read-only-country-footer">
            <div className="read-only-country-cell">Total</div>
            <div className="read-only-country-cell">
              {value.reduce((sum: number, item: any) => sum + (item.percent || 0), 0)}%
            </div>
          </div>
        </div>
      </div>
    )
  }

  // For other array types
  return (
    <div className="read-only-array-container">
      <div className="read-only-array-title">{schema.title || path}</div>
      {schema.description && <div className="read-only-array-description">{schema.description}</div>}
      <ul className="read-only-array-list">
        {value.map((item: any, index: number) => (
          <li key={index} className="read-only-array-item">
            {typeof item === "object" ? JSON.stringify(item) : item}
          </li>
        ))}
      </ul>
    </div>
  )
}

export const readOnlyArrayTester: RankedTester = rankWith(4, and(isArrayControl, hasType("array")))

export default withJsonFormsControlProps(ReadOnlyArrayRenderer)
