import { type ControlProps, type RankedTester, rankWith, isEnumControl, and, hasType } from "@jsonforms/core"
import { withJsonFormsControlProps } from "@jsonforms/react"

/**
 * A custom renderer for enum fields (single or multiple)
 * Displays question on left, answer on right with badges
 */
export const ReadOnlyEnumRenderer = ({ data, path, schema, uischema }: ControlProps) => {
  const value = data ? data[path.split("/").pop() as string] : undefined
  const isMultiEnum = Array.isArray(value)

  return (
    <div className="read-only-label-container">
      <div className="read-only-label-left">
        <div className="read-only-label-title">{schema.title || path}</div>
        {schema.description && <div className="read-only-label-description">{schema.description}</div>}
      </div>
      <div className="read-only-label-right">
        {isMultiEnum ? (
          <div className="read-only-enum-container">
            {value &&
              value.map((item: string, index: number) => (
                <span key={index} className="read-only-enum-badge">
                  {item}
                </span>
              ))}
          </div>
        ) : (
          <span className="read-only-enum-badge">{value}</span>
        )}
      </div>
    </div>
  )
}

export const readOnlyEnumTester: RankedTester = rankWith(4, and(isEnumControl, hasType("string")))

export default withJsonFormsControlProps(ReadOnlyEnumRenderer)
