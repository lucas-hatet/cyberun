import {
  type ControlProps,
  type RankedTester,
  rankWith,
  isStringControl,
  and,
  hasType,
  optionIs,
} from "@jsonforms/core"
import { withJsonFormsControlProps } from "@jsonforms/react"

/**
 * A custom renderer for multi-line text fields
 * Displays answer below the question (full width)
 */
export const ReadOnlyMultilineRenderer = ({ data, path, schema, uischema }: ControlProps) => {
  const value = data ? data[path.split("/").pop() as string] : undefined

  return (
    <div className="read-only-multiline-container">
      <div className="read-only-multiline-title">{schema.title || path}</div>
      {schema.description && <div className="read-only-multiline-description">{schema.description}</div>}
      <div className="read-only-multiline-content">
        {value
          ? value.split("\n").map((line: string, i: number) => (
              <p key={i} className="read-only-multiline-line">
                {line}
              </p>
            ))
          : ""}
      </div>
    </div>
  )
}

export const readOnlyMultilineTester: RankedTester = rankWith(
  5,
  and(isStringControl, hasType("string"), optionIs("multi", true)),
)

export default withJsonFormsControlProps(ReadOnlyMultilineRenderer)
